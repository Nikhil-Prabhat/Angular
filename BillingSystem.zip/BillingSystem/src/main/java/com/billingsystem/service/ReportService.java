package com.billingsystem.service;

import net.sf.jasperreports.engine.JRException;

public interface ReportService {

	public byte[] exportToPdf() throws Exception, JRException;

}
