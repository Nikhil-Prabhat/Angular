package com.billingsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billingsystem.entity.Cart;
import com.billingsystem.repository.CartRepository;

@Service
public class CartServiceImpl implements CartService {

	public static String DELETE_CART_ITEM = "Cart Item deleted successfully";

	@Autowired
	private CartRepository cartRepository;
	
	@Override
	public Cart getCartItemById(int id) {
		Cart cart = cartRepository.findById(id).orElse(null);
		return cart;
	}

	@Override
	public List<Cart> getAllCartItems() {
		List<Cart> allCartItems = cartRepository.findAll();
		return allCartItems;
	}

	@Override
	public String deleteCartItem(int id) {
		cartRepository.deleteById(id);
		return DELETE_CART_ITEM;
	}

	@Override
	public Cart addCartItem(Cart item) {
		Cart cartItem = cartRepository.save(item);
		return cartItem;
	}

	@Override
	public int totalAmount(List<Cart> cartItems) {
		int total = 0;
		for (Cart cart : cartItems) {
			total += cart.getAmount();
		}

		return total;
	}

	@Override
	public void deleteAllItems() {
		cartRepository.deleteAll();
	}

	

}
