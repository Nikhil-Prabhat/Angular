insert into product(description,price,quantity,rate) values('12A Pro',385,10,500);
insert into product(description,price,quantity,rate) values('Canon 324',920,20,1200);