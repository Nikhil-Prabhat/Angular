package com.nikhil.ws.soap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
