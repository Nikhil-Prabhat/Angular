package com.nikhil.ws.soap;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.apache.cxf.feature.Features;

//Making the endpoint

//Marking the class as service class
@WebService
@Features(features="org.apache.cxf.feature.LoggingFeature")
public class HelloWs {
	
	//Marking the method as webmethod
	@WebMethod
	public String hello()
	{
		return "hello";
	}

}
