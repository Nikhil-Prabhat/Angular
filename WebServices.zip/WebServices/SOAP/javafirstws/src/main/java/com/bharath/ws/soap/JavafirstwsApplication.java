package com.bharath.ws.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavafirstwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavafirstwsApplication.class, args);
	}
}
