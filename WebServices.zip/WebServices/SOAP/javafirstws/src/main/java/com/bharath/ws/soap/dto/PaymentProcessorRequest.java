package com.bharath.ws.soap.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

//Mark the class with JAXB annotation to create a wsdl file\

@XmlType  //Creation of complexType
@XmlAccessorType(XmlAccessType.FIELD) //Signifies how to access i.e field level or method level
public class PaymentProcessorRequest {

	@XmlElement
	private CreditCardInfo creditCardInfo;
	
	@XmlElement
	private Double amount;

	public CreditCardInfo getCreditCardInfo() {
		return creditCardInfo;
	}

	public void setCreditCardInfo(CreditCardInfo creditCardInfo) {
		this.creditCardInfo = creditCardInfo;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

}
