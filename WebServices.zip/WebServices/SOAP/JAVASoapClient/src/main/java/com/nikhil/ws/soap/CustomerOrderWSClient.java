package com.nikhil.ws.soap;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import com.bharath.ws.trainings.CustomerOrdersPortType;
import com.bharath.ws.trainings.GetOrdersRequest;
import com.bharath.ws.trainings.GetOrdersResponse;
import com.bharath.ws.trainings.Order;

public class CustomerOrderWSClient {
	
	public static void main(String[] args) throws MalformedURLException
	{
		//A delegate and provider is created which creates the java client at run time on flight
		//Create the service stub and the port
		CustomerOrdersWSImplService service = new CustomerOrdersWSImplService(new URL("http://localhost:8080/wsdlfirstws/customerorderservice?wsdl"));
		CustomerOrdersPortType customerOrdersWSImplPort = service.getCustomerOrdersWSImplPort();
		
		
		//Port can be used to call the methods i.e request and response
		GetOrdersRequest request = new GetOrdersRequest();
		request.setCustomerId(BigInteger.valueOf(1));
		GetOrdersResponse response = customerOrdersWSImplPort.getOrders(request);
		List<Order> orders = response.getOrder();
		
		System.out.println("No of orders for the customer are : "+orders.size());
		System.out.println("Orders -> "+orders);
	}

}
