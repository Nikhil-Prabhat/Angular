package com.nikhil.ws.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsdlFirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(WsdlFirstApplication.class, args);
	}

}
