package com.schoolmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.schoolmanagement.client.AuthClient;
import com.schoolmanagement.entity.Teacher;
import com.schoolmanagement.model.AuthResponse;
import com.schoolmanagement.service.TeacherServiceImpl;

@RestController
@RequestMapping("/teacherservice")
public class TeacherController {

	@Autowired
	private TeacherServiceImpl teacherService;

	@Autowired
	private AuthClient authClient;

	@GetMapping("/teacherslist")
	public ResponseEntity<?> getAllTeachers(@RequestHeader("Authorization") String token) {

		AuthResponse authResponse = authClient.getValidity(token);
		if ((authResponse.getRoles().equals("ROLE_TEACHER") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			List<Teacher> allTeachers = teacherService.getAllTeachers();
			return new ResponseEntity<>(allTeachers, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@GetMapping("/teacherslistbyname")
	public ResponseEntity<?> getTeachersByName(@RequestHeader("Authorization") String token,
			@RequestParam("name") String name) {
		AuthResponse authResponse = authClient.getValidity(token);

		if ((authResponse.getRoles().equals("ROLE_TEACHER") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			List<Teacher> teachersByName = teacherService.getTeachersByName(name);
			return new ResponseEntity<>(teachersByName, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@PostMapping("/addteacher")
	public ResponseEntity<?> addTeacher(@RequestHeader("Authorization") String token, @RequestBody Teacher teacher) {

		AuthResponse authResponse = authClient.getValidity(token);
		if ((authResponse.getRoles().equals("ROLE_TEACHER") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			Teacher addTeacher = teacherService.addTeacher(teacher);
			return new ResponseEntity<>(addTeacher, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@PutMapping("/updateteacher")
	public ResponseEntity<?> updateTeacher(@RequestHeader("Authorization") String token, @RequestParam("id") int id,
			@RequestBody Teacher teacher) {
		AuthResponse authResponse = authClient.getValidity(token);
		if ((authResponse.getRoles().equals("ROLE_TEACHER") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			Teacher updateTeacher = teacherService.updateTeacher(id, teacher);
			return new ResponseEntity<>(updateTeacher, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@DeleteMapping("/deleteteacher")
	public ResponseEntity<?> deleteTeacher(@RequestHeader("Authorization") String token, @RequestParam("id") int id) {
		AuthResponse authResponse = authClient.getValidity(token);
		if ((authResponse.getRoles().equals("ROLE_TEACHER") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			String deleteTeacher = teacherService.deleteTeacher(id);
			return new ResponseEntity<>(deleteTeacher, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

}
