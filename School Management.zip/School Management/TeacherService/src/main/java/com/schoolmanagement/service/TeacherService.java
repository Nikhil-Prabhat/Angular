package com.schoolmanagement.service;

import java.util.List;

import com.schoolmanagement.entity.Teacher;

public interface TeacherService {

	public List<Teacher> getAllTeachers();

	public List<Teacher> getTeachersByName(String name);

	public Teacher addTeacher(Teacher teacher);

	public Teacher updateTeacher(int id, Teacher teacher);

	public String deleteTeacher(int id);

}
