package com.schoolmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolmanagement.entity.Teacher;
import com.schoolmanagement.repository.TeacherRepository;

@Service
public class TeacherServiceImpl implements TeacherService {

	public static String TEACHER_ON_DELETE = "Teacher deleted successfully";

	@Autowired
	private TeacherRepository teacherRepository;

	@Override
	public List<Teacher> getAllTeachers() {
		List<Teacher> teacherList = teacherRepository.findAll();
		return teacherList;
	}

	@Override
	public List<Teacher> getTeachersByName(String name) {
		List<Teacher> teachersByName = teacherRepository.getTeachersByName(name);
		return teachersByName;
	}

	@Override
	public Teacher addTeacher(Teacher teacher) {
		Teacher saveTeacher = teacherRepository.save(teacher);
		return saveTeacher;
	}

	@Override
	public Teacher updateTeacher(int id, Teacher teacher) {
		Teacher teacherUpdate = teacherRepository.findById(id).orElse(null);

		if (teacherUpdate != null) {
			teacherUpdate.setAddress(teacher.getAddress());
			teacherUpdate.setBirthDate(teacher.getBirthDate());
			teacherUpdate.setDivision(teacher.getDivision());
			teacherUpdate.setEmail(teacher.getEmail());
			teacherUpdate.setGender(teacher.getGender());
			teacherUpdate.setJoinDate(teacher.getJoinDate());
			teacherUpdate.setPhone(teacher.getPhone());
			teacherUpdate.setQualification(teacher.getQualification());
			teacherUpdate.setStandard(teacher.getStandard());
			teacherUpdate.setTeacherName(teacher.getTeacherName());

			teacherRepository.save(teacherUpdate);
			return teacherUpdate;
		} else
			return null;
	}

	@Override
	public String deleteTeacher(int id) {
		teacherRepository.deleteById(id);
		return TEACHER_ON_DELETE;
	}

}
