package com.schoolmanagement.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.schoolmanagement.model.AuthResponse;

@FeignClient(url = "http://localhost:8090/authservice", name = "AuthService")
public interface AuthClient {

	@RequestMapping(value = "/validate", method = RequestMethod.GET)
	public AuthResponse getValidity(@RequestHeader(name = "Authorization", required = true) String token);

}
