package com.billingsystem.service;

import java.util.List;

import com.billingsystem.entity.Cart;

public interface CartService {

	public Cart getCartItemById(int id);

	public List<Cart> getAllCartItems();

	public int totalAmount(List<Cart> cartItems);

	public Cart addCartItem(Cart item);

	public String deleteCartItem(int id);

	public void deleteAllItems();

}
