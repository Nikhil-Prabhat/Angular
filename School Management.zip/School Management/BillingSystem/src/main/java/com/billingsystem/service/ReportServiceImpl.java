package com.billingsystem.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billingsystem.entity.Cart;
import com.billingsystem.entity.Product;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class ReportServiceImpl implements ReportService {

	@Autowired
	private CartService cartServiceImpl;

//	public static String RESULT = "pdf generated successfully";

	@Override
	public byte[] exportToPdf() throws Exception, JRException {

		List<Cart> allCartItems = cartServiceImpl.getAllCartItems();
		int total = cartServiceImpl.totalAmount(allCartItems);
		JRBeanCollectionDataSource datasource = new JRBeanCollectionDataSource(allCartItems);
		JasperReport jasperReport = JasperCompileManager
				.compileReport(new FileInputStream("src/main/resources/invoice.jrxml"));

		Map<String, Object> parameters = new HashMap<>();

		parameters.put("total", total);
		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, datasource);
		// JasperExportManager.exportReportToPdfFile(jasperPrint,
		// "C:\\Users\\Nik\\Desktop\\invoice.pdf");
		byte[] exportReportToPdf = JasperExportManager.exportReportToPdf(jasperPrint);
		return exportReportToPdf;

	}

}
