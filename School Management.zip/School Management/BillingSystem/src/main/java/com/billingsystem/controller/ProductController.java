package com.billingsystem.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Tuple;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.billingsystem.entity.Product;
import com.billingsystem.service.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductService productServiceImpl;

	@GetMapping("/getall")
	public ModelAndView getAllProducts() {

		ModelAndView modelAndView = new ModelAndView("home");
		List<Product> allProducts = productServiceImpl.getAllProducts();
		modelAndView.addObject("allProducts", allProducts);
		return modelAndView;
	}

	@GetMapping("/add")
	public ModelAndView getInventoryPage() {
		ModelAndView modelAndView = new ModelAndView("inventory");
		return modelAndView;
	}

	@GetMapping("/getbyid")
	public Product getProductById(@RequestParam("id") int id) {
		Product productById = productServiceImpl.getProductById(id);
		return productById;
	}

	@PostMapping("/add")
	public ModelAndView addProduct(@ModelAttribute("product") Product product) {
		ModelAndView modelAndView = new ModelAndView("inventory");
		productServiceImpl.addProduct(product);
		return modelAndView;
	}

	@GetMapping("/update")
	public ModelAndView getEditpage(@RequestParam("id") int id) {
		ModelAndView modelAndView = new ModelAndView("editproduct");
		modelAndView.addObject("id", id);
		return modelAndView;
	}

	@PostMapping("/update")
	public ModelAndView updateProduct(@RequestParam("id") String id, @ModelAttribute("product") Product product) {
		int operation = Integer.parseInt(product.getOperation());
		productServiceImpl.updateProduct(Integer.parseInt(id), product, operation);
		return new ModelAndView("redirect:update?id=" + id);
	}

	@GetMapping("/delete")
	public ModelAndView deleteProduct(@RequestParam("id") int id) {

		productServiceImpl.deleteProduct(id);
		return new ModelAndView("redirect:getall");
	}

	// Passing description and rate data to view

	@ModelAttribute("priceDetails")
	public Map<String, Integer> getDetails() {
		Map<String, Integer> infoMap = new HashMap<>();
		List<Tuple> allDetails = productServiceImpl.getAllDetails();

		for (Tuple tuple : allDetails) {
			String description = (String) tuple.get(0);
			int rate = (int) tuple.get(1);

			infoMap.put(description, rate);
		}

		return infoMap;
	}

}
