package com.billingsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.billingsystem.entity.Cart;
import com.billingsystem.service.CartService;
import com.billingsystem.service.ProductService;

@Controller
@RequestMapping("/cart")
public class CartController {

	@Autowired
	private CartService cartServiceImpl;

	@Autowired
	private ProductService productServiceImpl;

	@GetMapping("/emptycart")
	public ModelAndView getBillingPage() {
		ModelAndView modelAndView = new ModelAndView("billing");
		cartServiceImpl.deleteAllItems();
		return modelAndView;
	}

	@GetMapping("/getall")
	public ModelAndView getAllCartItems() {
		ModelAndView modelAndView = new ModelAndView("billing");
		List<Cart> allCartItems = cartServiceImpl.getAllCartItems();
		int total = cartServiceImpl.totalAmount(allCartItems);
		modelAndView.addObject("allCartItems", allCartItems);
		modelAndView.addObject("total", total);
		return modelAndView;
	}

	@PostMapping("/add")
	public ModelAndView addCartItem(@ModelAttribute("cart") Cart cart) {
		// ModelAndView modelAndView = new ModelAndView("billing");
		cartServiceImpl.addCartItem(cart);
		productServiceImpl.updateProductAccCart(cart, 0);
		return new ModelAndView("redirect:getall");
	}

	@GetMapping("/delete")
	public ModelAndView deleteCartItem(@RequestParam("id") int id) {
		Cart cart = cartServiceImpl.getCartItemById(id);
		cartServiceImpl.deleteCartItem(id);
		productServiceImpl.updateProductAccCart(cart, 1);
		return new ModelAndView("redirect:getall");
	}

}
