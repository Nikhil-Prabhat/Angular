package com.billingsystem.service;

import java.util.List;

import javax.persistence.Tuple;

import com.billingsystem.entity.Cart;
import com.billingsystem.entity.Product;

public interface ProductService {

	public List<Product> getAllProducts();

	public Product getProductById(int id);

	public Product addProduct(Product product);

	public Product updateProduct(int id, Product product,int operation);
	
	public Product updateProductAccCart(Cart cart,int operation);

	public String deleteProduct(int id);
	
	public List<Tuple> getAllDetails();

}
