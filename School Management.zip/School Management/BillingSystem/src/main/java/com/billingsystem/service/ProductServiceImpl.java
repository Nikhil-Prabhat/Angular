package com.billingsystem.service;

import java.util.List;

import javax.persistence.Tuple;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billingsystem.entity.Cart;
import com.billingsystem.entity.Product;
import com.billingsystem.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	public static String DELETE_PRODUCT = "Product deleted successfully";

	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> getAllProducts() {
		List<Product> allProducts = productRepository.findAll();
		return allProducts;
	}

	@Override
	public Product getProductById(int id) {
		Product productById = productRepository.findById(id).orElse(null);
		return productById;
	}

	@Override
	public Product addProduct(Product product) {
		Product addProduct = productRepository.save(product);
		return addProduct;
	}

	@Override
	public Product updateProduct(int id, Product product, int operation) {
		Product updateProduct = productRepository.findById(id).orElse(null);

		if (updateProduct != null) {

			updateProduct.setDescription(product.getDescription());
			updateProduct.setPrice(product.getPrice());
			updateProduct.setRate(product.getRate());
			if (operation == 0) {
				updateProduct.setQuantity(updateProduct.getQuantity() - product.getQuantity());
			} else {
				updateProduct.setQuantity(updateProduct.getQuantity() + product.getQuantity());
			}

		}

		productRepository.save(updateProduct);

		return updateProduct;
	}

	@Override
	public String deleteProduct(int id) {
		productRepository.deleteById(id);
		return DELETE_PRODUCT;
	}

	@Override
	public List<Tuple> getAllDetails() {
		List<Tuple> allDetails = productRepository.getAllDetails();
		return allDetails;
	}

	@Override
	public Product updateProductAccCart(Cart cart, int operation) {

		int productId = cart.getProductId();
		Product product = getProductById(productId);

		if (product != null) {

			if (operation == 0) {
				product.setQuantity(product.getQuantity() - cart.getQuantity());
			} else
				product.setQuantity(product.getQuantity() + cart.getQuantity());

			productRepository.save(product);
		}

		return product;
	}

}
