insert into user(uid,upassword,uname,roles) values('admin','admin','admin','ROLE_ADMIN');
insert into user(uid,upassword,uname,roles) values('student','student','student','ROLE_STUDENT');
insert into user(uid,upassword,uname,roles) values('teacher','teacher','teacher','ROLE_TEACHER');