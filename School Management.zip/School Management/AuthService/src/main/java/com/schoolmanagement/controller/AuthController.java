package com.schoolmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.schoolmanagement.entity.SchoolUser;
import com.schoolmanagement.model.AuthResponse;
import com.schoolmanagement.repository.SchoolUserRepository;
import com.schoolmanagement.service.CustomerDetailsService;
import com.schoolmanagement.service.JwtUtil;

@RestController
@RequestMapping("/authservice")
public class AuthController {

	@Autowired
	private JwtUtil jwtutil;
	@Autowired
	private CustomerDetailsService custdetailservice;
	@Autowired
	private SchoolUserRepository urepo;

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<?> login(@RequestBody SchoolUser userlogincredentials) {
		final UserDetails userdetails = custdetailservice.loadUserByUsername(userlogincredentials.getUid());
		if (userdetails.getPassword().equals(userlogincredentials.getUpassword())) {
			return new ResponseEntity<>(
					new SchoolUser(userlogincredentials.getUid(), null, null, jwtutil.generateToken(userdetails),null),
					HttpStatus.OK);
		} else {

			return new ResponseEntity<>("Invalid Username or Password", HttpStatus.FORBIDDEN);
		}
	}

	@RequestMapping(value = "/validate", method = RequestMethod.GET)
	public ResponseEntity<?> getValidity(@RequestHeader("Authorization") String token) {

		token = token.substring(7);
		AuthResponse res = new AuthResponse();
		if (jwtutil.validateToken(token)) {
			res.setUid(jwtutil.extractUsername(token));
			res.setValid(true);
			res.setUname((urepo.findById(jwtutil.extractUsername(token)).orElse(null).getUname()));
			List<SimpleGrantedAuthority> roles = jwtutil.getRolesFromToken(token);
			res.setRoles(roles.get(0).getAuthority());

		} else
			res.setValid(false);

		return new ResponseEntity<>(res, HttpStatus.OK);
	}
}
