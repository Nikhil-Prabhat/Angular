package com.schoolmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import com.schoolmanagement.service.JwtUtil;

@RestController
public class ResourceController {
	
	@Autowired
	private JwtUtil jwtutil;
	
	@GetMapping("/admin")
	public String getAdmin(@RequestHeader("Authorization") String token) throws Exception
	{
		token=token.substring(7);
		if(jwtutil.validateToken(token) && jwtutil.getRolesFromToken(token).get(0).getAuthority().equals("ROLE_ADMIN"))
		{
			return "Hello Admin";
			
		}
		else
			throw new Exception("User Not Found");
	}
	
	@GetMapping("/student")
	public String getStudent(@RequestHeader("Authorization") String token) throws Exception
	{
		token=token.substring(7);
		if(jwtutil.validateToken(token) && jwtutil.getRolesFromToken(token).get(0).getAuthority().equals("ROLE_STUDENT"))
		{
			return "Hello Student";
			
		}
		else
			throw new Exception("User Not Found");
	}
	
	@GetMapping("/teacher")
	public String getTeacher(@RequestHeader("Authorization") String token) throws Exception
	{
		token=token.substring(7);
		if(jwtutil.validateToken(token) && jwtutil.getRolesFromToken(token).get(0).getAuthority().equals("ROLE_TEACHER"))
		{
			return "Hello Teacher";
			
		}
		else
			throw new Exception("User Not Found");
	}

}
