package com.schoolmanagement.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.schoolmanagement.entity.SchoolUser;
import com.schoolmanagement.repository.SchoolUserRepository;

@Service
public class CustomerDetailsService implements UserDetailsService {

	@Autowired
	private SchoolUserRepository schoolUserRepository;

	@Override
	public UserDetails loadUserByUsername(String uid) throws UsernameNotFoundException {
		List<SimpleGrantedAuthority> roles = null;
		SchoolUser schoolUser = schoolUserRepository.findById(uid).orElse(null);
		
		roles = Arrays.asList(new SimpleGrantedAuthority(schoolUser.getRoles()));
		
		return new User(schoolUser.getUid(), schoolUser.getUpassword(), roles);
	}

}
