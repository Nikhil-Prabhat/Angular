package com.schoolmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolmanagement.entity.Student;
import com.schoolmanagement.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	public static String RESPONSE_ON_DELETE = "Student deleted successfully";

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public List<Student> getAllStudents() {
		List<Student> studentList = studentRepository.findAll();
		return studentList;
	}

	@Override
	public List<Student> getStudentByName(String name) {
		List<Student> studentListByName = studentRepository.getStudentByName(name);
		return studentListByName;
	}

	@Override
	public Student addStudent(Student student) {
		Student saveStudent = studentRepository.save(student);
		return saveStudent;
	}

	@Override
	public Student updateStudent(int id, Student student) {
		Student studentUpdate = studentRepository.findById(id).orElse(null);

		if (studentUpdate != null) {
			studentUpdate.setAddress(student.getAddress());
			studentUpdate.setBirthDate(student.getBirthDate());
			studentUpdate.setDivision(student.getDivision());
			studentUpdate.setEmail(student.getEmail());
			studentUpdate.setFatherName(student.getFatherName());
			studentUpdate.setGender(student.getGender());
			studentUpdate.setMotherName(student.getMotherName());
			studentUpdate.setName(student.getName());
			studentUpdate.setPhone(student.getPhone());
			studentUpdate.setStandard(student.getStandard());
			studentRepository.save(studentUpdate);
			return studentUpdate;
		} else
			return null;
	}

	@Override
	public String deleteStudent(int id) {
		studentRepository.deleteById(id);
		return RESPONSE_ON_DELETE;
	}

}
