package com.schoolmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.schoolmanagement.client.AuthClient;
import com.schoolmanagement.entity.Student;
import com.schoolmanagement.model.AuthResponse;
import com.schoolmanagement.service.StudentServiceImpl;

@RestController
@RequestMapping("/studentservice")
public class StudentController {

	@Autowired
	private StudentServiceImpl studentServiceImpl;

	@Autowired
	private AuthClient authClient;

	@GetMapping("/studentlist")
	public ResponseEntity<?> getAllStudents(@RequestHeader("Authorization") String token) {

		AuthResponse authResponse = authClient.getValidity(token);

		if ((authResponse.getRoles().equals("ROLE_STUDENT") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			List<Student> allStudents = studentServiceImpl.getAllStudents();
			return new ResponseEntity<>(allStudents, HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
		}
	}

	@GetMapping("/studentlistbyname")
	public ResponseEntity<?> getStudentByName(@RequestHeader("Authorization") String token,
			@RequestParam("name") String name) {
		AuthResponse authResponse = authClient.getValidity(token);

		if ((authResponse.getRoles().equals("ROLE_STUDENT") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			List<Student> studentByName = studentServiceImpl.getStudentByName(name);
			return new ResponseEntity<>(studentByName, HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
		}
	}

	@PostMapping("/addstudent")
	public ResponseEntity<?> addStudent(@RequestHeader("Authorization") String token, @RequestBody Student student) {

		AuthResponse authResponse = authClient.getValidity(token);
		if ((authResponse.getRoles().equals("ROLE_STUDENT") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			Student addStudent = studentServiceImpl.addStudent(student);
			return new ResponseEntity<>(addStudent, HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
		}
	}

	@PutMapping("/updatestudent")
	public ResponseEntity<?> updateStudent(@RequestHeader("Authorization") String token, @RequestParam("id") int id,
			@RequestBody Student student) {

		AuthResponse authResponse = authClient.getValidity(token);
		if ((authResponse.getRoles().equals("ROLE_STUDENT") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			System.out.println("Id --> " + id);
			Student updateStudent = studentServiceImpl.updateStudent(id, student);
			return new ResponseEntity<>(updateStudent, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@DeleteMapping("/deletestudent")
	public ResponseEntity<?> deleteStudent(@RequestHeader("Authorization") String token, @RequestParam("id") int id) {
		AuthResponse authResponse = authClient.getValidity(token);
		if ((authResponse.getRoles().equals("ROLE_STUDENT") || authResponse.getRoles().equals("ROLE_ADMIN"))
				&& authResponse.isValid()) {
			String deleteStudent = studentServiceImpl.deleteStudent(id);
			return new ResponseEntity<>(deleteStudent, HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
		}
	}

}
