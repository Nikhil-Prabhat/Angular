package com.schoolmanagement.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.schoolmanagement.model.Student;

@FeignClient(url = "http://localhost:8080/studentservice", name = "StudentService")
public interface StudentClient {

	@GetMapping("/studentlist")
	public List<Student> getAllStudents(@RequestHeader("Authorization") String token);

	@GetMapping("/studentlistbyname")
	public List<Student> getStudentByName(@RequestHeader("Authorization") String token,
			@RequestParam("name") String name);

	@PostMapping("/addstudent")
	public Student addStudent(@RequestHeader("Authorization") String token, @RequestBody Student student);

	@PutMapping("/updatestudent")
	public Student updateStudent(@RequestHeader("Authorization") String token, @RequestParam("id") int id,
			@RequestBody Student student);

	@DeleteMapping("/deletestudent")
	public String deleteStudent(@RequestHeader("Authorization") String token, @RequestParam("id") int id);

}
