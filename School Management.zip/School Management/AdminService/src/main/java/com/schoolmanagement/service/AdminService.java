package com.schoolmanagement.service;

import java.util.List;

import com.schoolmanagement.model.Student;
import com.schoolmanagement.model.Teacher;

public interface AdminService {

	// Methods for student manipulation
	public List<Student> getAllStudents(String token);

	public List<Student> getStudentByName(String token, String name);

	public Student addStudent(String token, Student student);

	public Student updateStudent(String token, int id, Student student);

	public String deleteStudent(String token, int id);

	// Method for teacher manipulation

	public List<Teacher> getAllTeachers(String token);

	public List<Teacher> getTeachersByName(String token,String name);

	public Teacher addTeacher(String token,Teacher teacher);

	public Teacher updateTeacher(String token,int id, Teacher teacher);

	public String deleteTeacher(String token,int id);

}
