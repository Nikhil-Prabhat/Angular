package com.schoolmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolmanagement.client.StudentClient;
import com.schoolmanagement.client.TeacherClient;
import com.schoolmanagement.model.Student;
import com.schoolmanagement.model.Teacher;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private StudentClient studentClient;

	@Autowired
	private TeacherClient teacherClient;

	@Override
	public List<Student> getAllStudents(String token) {
		List<Student> allStudents = studentClient.getAllStudents(token);
		return allStudents;
	}

	@Override
	public List<Student> getStudentByName(String token,String name) {
		List<Student> studentByName = studentClient.getStudentByName(token,name);
		return studentByName;
	}

	@Override
	public Student addStudent(String token,Student student) {
		Student addStudent = studentClient.addStudent(token,student);
		return addStudent;
	}

	@Override
	public Student updateStudent(String token,int id, Student student) {
		Student updateStudent = studentClient.updateStudent(token,id, student);
		return updateStudent;
	}

	@Override
	public String deleteStudent(String token,int id) {
		String deleteStudent = studentClient.deleteStudent(token,id);
		return deleteStudent;
	}

	@Override
	public List<Teacher> getAllTeachers(String token) {
		List<Teacher> allTeachers = teacherClient.getAllTeachers(token);
		return allTeachers;
	}

	@Override
	public List<Teacher> getTeachersByName(String token,String name) {
		List<Teacher> teachersByName = teacherClient.getTeachersByName(token,name);
		return teachersByName;
	}

	@Override
	public Teacher addTeacher(String token,Teacher teacher) {
		Teacher addTeacher = teacherClient.addTeacher(token,teacher);
		return addTeacher;
	}

	@Override
	public Teacher updateTeacher(String token,int id, Teacher teacher) {
		Teacher updateTeacher = teacherClient.updateTeacher(token,id, teacher);
		return updateTeacher;
	}

	@Override
	public String deleteTeacher(String token,int id) {
		String deleteTeacher = teacherClient.deleteTeacher(token,id);
		return deleteTeacher;
	}

}
