package com.schoolmanagement.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.schoolmanagement.model.Teacher;

@FeignClient(url = "http://localhost:8081/teacherservice", name = "TeacherService")
public interface TeacherClient {

	@GetMapping("/teacherslist")
	public List<Teacher> getAllTeachers(@RequestHeader("Authorization") String token);

	@GetMapping("/teacherslistbyname")
	public List<Teacher> getTeachersByName(@RequestHeader("Authorization") String token,
			@RequestParam("name") String name);

	@PostMapping("/addteacher")
	public Teacher addTeacher(@RequestHeader("Authorization") String token, @RequestBody Teacher teacher);

	@PutMapping("/updateteacher")
	public Teacher updateTeacher(@RequestHeader("Authorization") String token, @RequestParam("id") int id,
			@RequestBody Teacher teacher);

	@DeleteMapping("/deleteteacher")
	public String deleteTeacher(@RequestHeader("Authorization") String token, @RequestParam("id") int id);

}
