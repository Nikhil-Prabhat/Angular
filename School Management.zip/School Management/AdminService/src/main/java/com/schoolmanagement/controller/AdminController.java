package com.schoolmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.schoolmanagement.client.AuthClient;
import com.schoolmanagement.model.AuthResponse;
import com.schoolmanagement.model.Student;
import com.schoolmanagement.model.Teacher;
import com.schoolmanagement.service.AdminService;

@RestController
@RequestMapping("/adminservice")
public class AdminController {

	@Autowired
	private AdminService adminService;

	@Autowired
	private AuthClient authClient;

	@GetMapping("/studentlist")
	public ResponseEntity<?> getAllStudents(@RequestHeader("Authorization") String token) {
		AuthResponse authResponse = authClient.getValidity(token);
		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			List<Student> allStudents = adminService.getAllStudents(token);
			return new ResponseEntity<>(allStudents, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@GetMapping("/teacherslist")
	public ResponseEntity<?> getAllTeachers(@RequestHeader("Authorization") String token) {
		AuthResponse authResponse = authClient.getValidity(token);
		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			List<Teacher> allTeachers = adminService.getAllTeachers(token);
			return new ResponseEntity<>(allTeachers, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Aceess Denied", HttpStatus.FORBIDDEN);
	}

	@GetMapping("/studentlistbyname")
	public ResponseEntity<?> getStudentByName(@RequestHeader("Authorization") String token, String name) {
		AuthResponse authResponse = authClient.getValidity(token);
		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			List<Student> studentByName = adminService.getStudentByName(token, name);
			return new ResponseEntity<>(studentByName, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@GetMapping("/teacherslistbyname")
	public ResponseEntity<?> getTeachersByName(@RequestHeader("Authorization") String token,
			@RequestParam("name") String name) {
		AuthResponse authResponse = authClient.getValidity(token);
		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			List<Teacher> teachersByName = adminService.getTeachersByName(token, name);
			return new ResponseEntity<>(teachersByName, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@PostMapping("/addstudent")
	public ResponseEntity<?> addStudent(@RequestHeader("Authorization") String token, Student student) {
		AuthResponse authResponse = authClient.getValidity(token);
		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			Student addStudent = adminService.addStudent(token, student);
			return new ResponseEntity<>(addStudent, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@PostMapping("/addteacher")
	public ResponseEntity<?> addTeacher(@RequestHeader("Authorization") String token, @RequestBody Teacher teacher) {
		AuthResponse authResponse = authClient.getValidity(token);
		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			Teacher addTeacher = adminService.addTeacher(token, teacher);
			return new ResponseEntity<>(addTeacher, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@PutMapping("/updatestudent")
	public ResponseEntity<?> updateStudent(@RequestHeader("Authorization") String token, int id, Student student) {
		AuthResponse authResponse = authClient.getValidity(token);
		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			Student updateStudent = adminService.updateStudent(token, id, student);
			return new ResponseEntity<>(updateStudent, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@PutMapping("/updateteacher")
	public ResponseEntity<?> updateTeacher(@RequestHeader("Authorization") String token, @RequestParam("id") int id,
			@RequestBody Teacher teacher) {
		AuthResponse authResponse = authClient.getValidity(token);

		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			Teacher updateTeacher = adminService.updateTeacher(token, id, teacher);
			return new ResponseEntity<>(updateTeacher, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@DeleteMapping("/deletestudent")
	public ResponseEntity<?> deleteStudent(@RequestHeader("Authorization") String token, int id) {
		AuthResponse authResponse = authClient.getValidity(token);
		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			String deleteStudent = adminService.deleteStudent(token, id);
			return new ResponseEntity<>(deleteStudent, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}

	@DeleteMapping("/deleteteacher")
	public ResponseEntity<?> deleteTeacher(@RequestHeader("Authorization") String token, @RequestParam("id") int id) {
		AuthResponse authResponse = authClient.getValidity(token);
		if (authResponse.getRoles().equals("ROLE_ADMIN") && authResponse.isValid()) {
			String deleteTeacher = adminService.deleteTeacher(token, id);
			return new ResponseEntity<>(deleteTeacher, HttpStatus.OK);
		} else
			return new ResponseEntity<>("Access Denied", HttpStatus.FORBIDDEN);
	}
}
