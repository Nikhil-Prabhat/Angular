package com.schoolmanagement.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Student {

	private int id;
	private String name;
	private String fatherName;
	private String motherName;
	private String gender;
	private String standard;
	private String division;
	private Date birthDate;
	private String phone;
	private String email;
	private String address;
}
