package com.schoolmanagement.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Teacher {

	private int id;
	private String teacherName;
	private String gender;
	private String standard;
	private String division;
	private String qualification;
	private Date birthDate;
	private Date joinDate;
	private String phone;
	private String email;
	private String address;
}
